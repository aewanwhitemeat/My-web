
# Aewans White Meat

Fresh, healthy white meat products delivered to your door.

## Website Features
- Fresh Chicken, Tilapia Fish, Rabbit Meat, Turkey
- Online Ordering via WhatsApp
- Home Delivery
- Onsite Purchase
- Bulk Supplies for Events and Businesses
- Smooth Scrolling
- Scroll-to-Top Button
- Active Link Highlighting
- Mobile Responsive Design

## Technologies Used
- HTML5
- CSS3
- Vanilla JavaScript
- Google Fonts (Poppins)

## How to Use
1. Clone the repository:
   ```
   git clone https://github.com/YOUR-USERNAME/aewans-white-meat.git
   ```
2. Open `index.html` in your browser.

## Contact
- WhatsApp: +254700768025
- Email: andrewewat@gmail.com
- Instagram: [@aewan2025](https://instagram.com/aewan2025)

---
© 2025 Aewans White Meat. All rights reserved.
